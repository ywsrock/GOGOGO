# test runtimes

This directory provides OS runtimes to test `gosseract` behaviors, and also explains how to install `gosseract` on each OS.

Just hit `./test/runtime` to execute all runtime tests (with `docker` and `vagrant` required).

[![asciicast](https://asciinema.org/a/x5qV41l7P2N9fmSB1UWvO1Itq.png)](https://asciinema.org/a/x5qV41l7P2N9fmSB1UWvO1Itq)
