# pixelmatch
[mapbox/pixelmatch](https://github.com/mapbox/pixelmatch) ports for go.

## Installation
library

```bash
go get github.com/orisano/pixelmatch
```

cli
```bash
go get github.com/orisano/pixelmatch/cmd/pixelmatch
```

## Author
Nao Yonashiro (@orisano)

## License
MIT
